CREATE TRIGGER order_info_trigger
  AFTER INSERT
  ON order_info
  FOR EACH ROW
  begin
INSERT INTO order_info_ex(O_EX_ID,O_EX_NAME) VALUES ( default,new.ORDER_NUMBER);
end;

