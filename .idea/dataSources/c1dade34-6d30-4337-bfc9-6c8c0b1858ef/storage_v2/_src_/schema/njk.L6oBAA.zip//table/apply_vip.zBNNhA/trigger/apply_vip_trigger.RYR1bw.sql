CREATE TRIGGER apply_vip_trigger
  AFTER INSERT
  ON apply_vip
  FOR EACH ROW
  begin
INSERT INTO apply_vip_ex(V_EX_ID,V_EX_NAME) VALUES ( default,new.NAME);
end;

