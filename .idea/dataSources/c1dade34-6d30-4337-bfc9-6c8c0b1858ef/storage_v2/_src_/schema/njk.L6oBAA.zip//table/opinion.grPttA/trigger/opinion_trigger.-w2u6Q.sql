CREATE TRIGGER opinion_trigger
  AFTER INSERT
  ON opinion
  FOR EACH ROW
  begin
INSERT INTO opinion_ex(OP_EX_ID,OP_EX_NAME) VALUES ( default,new.PHONE);
end;

